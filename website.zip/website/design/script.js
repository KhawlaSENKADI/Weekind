document.addEventListener('DOMContentLoaded', function() {
    const canvas = new fabric.Canvas('design-canvas', {
        backgroundColor: '#ffffff',
        preserveObjectStacking: true
    });

    // Add text to canvas
    document.getElementById('add-text-btn').addEventListener('click', function() {
        const text = new fabric.Textbox('Your Text', {
            left: 50,
            top: 50,
            fontSize: 30,
            fill: '#000000'
        });
        canvas.add(text);
        canvas.setActiveObject(text);
        showPropertiesPanel('text-properties');
    });

    // Add image to canvas
    document.getElementById('add-image-btn').addEventListener('click', function() {
        fabric.Image.fromURL('example.jpg', function(img) {
            img.scaleToWidth(200); // Adjust as needed
            img.scaleToHeight(200); // Adjust as needed
            canvas.add(img);
            canvas.setActiveObject(img);
            showPropertiesPanel('image-properties');
        });
    });

    // Add shape to canvas
    document.getElementById('add-shape-btn').addEventListener('click', function() {
        const rect = new fabric.Rect({
            left: 100,
            top: 100,
            fill: '#ff0000',
            width: 100,
            height: 100
        });
        canvas.add(rect);
        canvas.setActiveObject(rect);
        showPropertiesPanel('shape-properties');
    });

    // Undo action
    document.getElementById('undo-btn').addEventListener('click', function() {
        canvas.undo();
    });

    // Redo action
    document.getElementById('redo-btn').addEventListener('click', function() {
        canvas.redo();
    });

    // Save canvas as image
    document.getElementById('save-btn').addEventListener('click', function() {
        canvas.toDataURL({
            format: 'png',
            quality: 0.8,
            multiplier: 2
        });
    });

    // Listen for object selection on canvas
    canvas.on('object:selected', function(e) {
        const selectedObject = e.target;
        if (selectedObject.type === 'textbox') {
            showPropertiesPanel('text-properties');
        } else if (selectedObject.type === 'image') {
            showPropertiesPanel('image-properties');
        } else if (selectedObject.type === 'rect') {
            showPropertiesPanel('shape-properties');
        }
    });

    // Function to show properties panel for selected object type
    function showPropertiesPanel(panelId) {
        const panels = document.querySelectorAll('.properties-panel');
        panels.forEach(panel => {
            panel.classList.remove('active');
        });
        document.getElementById(panelId).classList.add('active');
    }

    // Update layers list
    function updateLayersList() {
        const layerList = document.getElementById('layer-list');
        layerList.innerHTML = '';
        canvas.getObjects().forEach((obj, index) => {
            const li = document.createElement('li');
            li.textContent = obj.type.charAt(0).toUpperCase() + obj.type.slice(1) + ' ' + (index + 1);
            li.addEventListener('click', function() {
                canvas.setActiveObject(obj);
            });
            layerList.appendChild(li);
        });
    }

    // Update layers list on canvas object modification
    canvas.on('object:added', updateLayersList);
    canvas.on('object:removed', updateLayersList);
    canvas.on('object:modified', updateLayersList);
});
