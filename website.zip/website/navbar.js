const navbarHTML = `
  <aside class="sidebar">
    <div class="sidebar-header">
   
    </div>
    <ul class="sidebar-links">
      <h4>

        <span>Main Menu</span>
        <div class="menu-separator"></div>
      </h4>
            <li>
        <a href="profile.html">
          <span class="material-symbols-outlined"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="M234-276q51-39 114-61.5T480-360q69 0 132 22.5T726-276q35-41 54.5-93T800-480q0-133-93.5-226.5T480-800q-133 0-226.5 93.5T160-480q0 59 19.5 111t54.5 93Zm246-164q-59 0-99.5-40.5T340-580q0-59 40.5-99.5T480-720q59 0 99.5 40.5T620-580q0 59-40.5 99.5T480-440Zm0 360q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q53 0 100-15.5t86-44.5q-39-29-86-44.5T480-280q-53 0-100 15.5T294-220q39 29 86 44.5T480-160Zm0-360q26 0 43-17t17-43q0-26-17-43t-43-17q-26 0-43 17t-17 43q0 26 17 43t43 17Zm0-60Zm0 360Z"/></svg></span> profile
        </a>
      </li>
   
      <li>
        <a href="Notes-App-main/index.html">
          <span class="material-symbols-outlined"> <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="M160-400v-80h280v80H160Zm0-160v-80h440v80H160Zm0-160v-80h440v80H160Zm360 560v-123l221-220q9-9 20-13t22-4q12 0 23 4.5t20 13.5l37 37q8 9 12.5 20t4.5 22q0 11-4 22.5T863-380L643-160H520Zm300-263-37-37 37 37ZM580-220h38l121-122-18-19-19-18-122 121v38Zm141-141-19-18 37 37-18-19Z"/></svg> </span> Note
        </a>
      </li>

      <h4>
        <span>Sections</span>
        <div class="menu-separator"></div>
      </h4>
      <li>
        <a href="home.php">
          <span class="material-symbols-outlined"> <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="m260-520 220-360 220 360H260ZM700-80q-75 0-127.5-52.5T520-260q0-75 52.5-127.5T700-440q75 0 127.5 52.5T880-260q0 75-52.5 127.5T700-80Zm-580-20v-320h320v320H120Zm580-60q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm-500-20h160v-160H200v160Zm202-420h156l-78-126-78 126Zm78 0ZM360-340Zm340 80Z"/></svg> </span>weekind
        </a>
      </li>
      <li>
        <a href="weecraft.html">
          <span class="material-symbols-outlined"> <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="m260-520 220-360 220 360H260ZM700-80q-75 0-127.5-52.5T520-260q0-75 52.5-127.5T700-440q75 0 127.5 52.5T880-260q0 75-52.5 127.5T700-80Zm-580-20v-320h320v320H120Zm580-60q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm-500-20h160v-160H200v160Zm202-420h156l-78-126-78 126Zm78 0ZM360-340Zm340 80Z"/></svg> </span>weecraft
        </a>
      </li>
      <li>
        <a href="lackey.html">
          <span class="material-symbols-outlined"> <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="m260-520 220-360 220 360H260ZM700-80q-75 0-127.5-52.5T520-260q0-75 52.5-127.5T700-440q75 0 127.5 52.5T880-260q0 75-52.5 127.5T700-80Zm-580-20v-320h320v320H120Zm580-60q42 0 71-29t29-71q0-42-29-71t-71-29q-42 0-71 29t-29 71q0 42 29 71t71 29Zm-500-20h160v-160H200v160Zm202-420h156l-78-126-78 126Zm78 0ZM360-340Zm340 80Z"/></svg> </span>lackey
        </a>
      </li>
      <h4>
        <span>Tools</span>
        <div class="menu-separator"></div>
      </h4>
      <li>
        <a href="gifty.html">
          <span class="material-symbols-outlined"> <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="M160-80v-440H80v-240h208q-5-9-6.5-19t-1.5-21q0-50 35-85t85-35q23 0 43 8.5t37 23.5q17-16 37-24t43-8q50 0 85 35t35 85q0 11-2 20.5t-6 19.5h208v240h-80v440H160Zm400-760q-17 0-28.5 11.5T520-800q0 17 11.5 28.5T560-760q17 0 28.5-11.5T600-800q0-17-11.5-28.5T560-840Zm-200 40q0 17 11.5 28.5T400-760q17 0 28.5-11.5T440-800q0-17-11.5-28.5T400-840q-17 0-28.5 11.5T360-800ZM160-680v80h280v-80H160Zm280 520v-360H240v360h200Zm80 0h200v-360H520v360Zm280-440v-80H520v80h280Z"/></svg> </span>gifty
        </a>
      </li>
      <li>
        <a href="#">
          <span class="material-symbols-outlined"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#ffffff"><path d="M240-400h320v-80H240v80Zm0-120h480v-80H240v80Zm0-120h480v-80H240v80ZM80-80v-720q0-33 23.5-56.5T160-880h640q33 0 56.5 23.5T880-800v480q0 33-23.5 56.5T800-240H240L80-80Zm126-240h594v-480H160v525l46-45Zm-46 0v-480 480Z"/></svg></span>interviews
        </a>
      </li>
 <li>
  <a href="landingpage/index.html" id="logout">
    <span class="material-symbols-outlined">logout</span> Logout
  </a>
</li>

    </ul>

  </aside>


  
`;

document.addEventListener("DOMContentLoaded", function() {
  const body = document.querySelector("body");
  body.insertAdjacentHTML("afterbegin", navbarHTML);

  // Fetch the username from the server
  fetch('php/get_username.php')
    .then(response => response.json())
    .then(data => {
      console.log('Fetched username:', data.username); // Debug log
      if (data.username) {
        document.getElementById('username').textContent = data.username;
      }
    })
    .catch(error => {
      console.error('Error fetching username:', error);
    });

  // Event handling for Gifty button and popup
  const giftyBtn = document.querySelector('.sidebar .sidebar-links li:nth-child(10) a'); // Adjust according to your structure
  const giftPopup = document.getElementById('gift-popup');
  const giftOverlay = document.getElementById('gift-overlay');
  const closeGiftPopup = document.getElementById('close-gift-popup');

  giftyBtn.addEventListener('click', function(event) {
    event.preventDefault(); // Prevent default link behavior
    giftPopup.style.display = 'block';
    giftOverlay.style.display = 'block';
  });

  closeGiftPopup.addEventListener('click', function() {
    giftPopup.style.display = 'none';
    giftOverlay.style.display = 'none';
  });

  giftOverlay.addEventListener('click', function() {
    giftPopup.style.display = 'none';
    giftOverlay.style.display = 'none';
  });
});

$(document).ready(function() {
    // Event listener for logout link click
    $('#logout').on('click', function(e) {
      e.preventDefault(); // Prevent the default action of the link
      
      // Perform logout action
      $.ajax({
        url: 'php/logout.php', // URL where your logout script is located
        method: 'POST', // Use POST method
        success: function(response) {
          // Assuming logout.php clears sessions or performs logout actions
          console.log('Logout successful'); // Log success
          window.location.href = 'landingpage/index.html'; // Redirect to login page
        },
        error: function(xhr, status, error) {
          console.error('Logout error:', error); // Log error
          alert('Failed to logout. Please try again.'); // Show error message
        }
      });
    });
  });
  

    // <div class="user-account">
    //   <div class="user-profile">
    //     <img src="images/profile-img.jpg" alt="Profile Image" />
    //     <div class="user-detail">
    //       <h3 id="username">Eva Murphy</h3>
    //       <span>Web Developer</span>
    //     </div>
    //   </div>
    // </div>


    //    <img src="images/logo.png" alt="logo" />
    //   <h2>CodingLab</h2>


        // <div class="user-account">
    //   <div class="user-profile">
    //     <img src="img/Design team-rafiki.png" alt="Profile Image" />
    //     <div class="user-detail">
    //       <h3 id="username">&nbsp;&nbsp;&nbsp;&nbsp;username</h3>
    //       <span>&nbsp;&nbsp;&nbsp;&nbsp;seller</span>
    //     </div>
    //   </div>
    // </div>


        //   <li>
    //     <a href="#">
    //       <span class="material-symbols-outlined"> monitoring </span>Analytics
    //     </a>
    //   </li>


//     <li>
//     <a href="#">
//       <span class="material-symbols-outlined"> dashboard </span>Dashboard
//     </a>
//   </li>