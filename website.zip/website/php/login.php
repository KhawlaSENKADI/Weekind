<?php
// login.php

session_start();

// Include database connection
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['name'];
    $password = $_POST['password'];

    // Validate input
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    // Hash password
    $hashed_password = md5($password);

    // SQL query to check if the user exists
    $sql = "SELECT id, username FROM users WHERE username='$username' AND password='$hashed_password'";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    // If user exists, start session and redirect to dashboard
    if ($row) {
        $_SESSION['user_id'] = $row['id']; // Store user_id in session
        $_SESSION['username'] = $row['username']; // Optionally store username
        header("location: /website/home.php");
    } else {
        echo "Invalid username or password";
    }
}
?>
