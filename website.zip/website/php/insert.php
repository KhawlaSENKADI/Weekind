<?php
$conn = mysqli_connect("localhost", "root", "", "product");

if ($conn === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$name = $_POST['name'];
$price = $_POST['price'];
$color = $_POST['color'];
$description = $_POST['description'];

$sql = "INSERT INTO products (name, price, color, description) VALUES ('$name', '$price', '$color', '$description')";

if (mysqli_query($conn, $sql)) {
    echo "Product added successfully.";
} else {
    echo "ERROR: Could not execute $sql. " . mysqli_error($conn);
}

mysqli_close($conn);
?>
