<?php
// connect to database
$conn = mysqli_connect("localhost", "root", "", "shadowmessenger");

// check connection
if (!$conn) {
    die("Connection failed: ". mysqli_connect_error());
}

// retrieve recipient and message from JavaScript
$recipient = $_POST['recipient'];
$message = $_POST['message'];

// get sender's ID from session
$sender_id = $_SESSION['user_id'];

// insert message into database
$query = "INSERT INTO messages (sender_id, recipient, message) VALUES ('$sender_id', '$recipient', '$message')";
if (mysqli_query($conn, $query)) {
    echo json_encode(array("success" => true));
} else {
    echo json_encode(array("success" => false, "error" => "Failed to send message"));
}

// close connection
mysqli_close($conn);
?>
