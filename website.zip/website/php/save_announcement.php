<?php
// Function to return JSON response
function jsonResponse($status, $message) {
    header('Content-Type: application/json');
    echo json_encode(array('status' => $status, 'message' => $message));
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbs";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        jsonResponse('error', 'Connection failed: ' . $conn->connect_error);
    }

    // Process form data
    $announcement_title = $conn->real_escape_string($_POST['announcement_title']);
    $announcement_about = $conn->real_escape_string($_POST['announcement_about']);

    // File upload handling
    $target_dir = "uploads/"; // Directory where the file will be stored
    $target_file = $target_dir . basename($_FILES["announcement_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a valid image
    $check = getimagesize($_FILES["announcement_image"]["tmp_name"]);
    if ($check === false) {
        jsonResponse('error', 'File is not an image.');
    }

    // Check file size (example limit: 1MB)
    if ($_FILES["announcement_image"]["size"] > 1000000) {
        jsonResponse('error', 'Sorry, your file is too large.');
    }

    // Allow only specific file formats
    if (!in_array($imageFileType, array("jpg", "jpeg", "png", "gif"))) {
        jsonResponse('error', 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
    }

    // Attempt to upload file and insert data into database
    if ($uploadOk === 1) {
        if (move_uploaded_file($_FILES["announcement_image"]["tmp_name"], $target_file)) {
            $sql = "INSERT INTO announcements (announcement_title, announcement_about, announcement_image)
                    VALUES ('$announcement_title', '$announcement_about', '$target_file')";

            if ($conn->query($sql) === TRUE) {
                jsonResponse('success', 'New announcement added successfully');
            } else {
                jsonResponse('error', 'Error adding announcement: ' . $conn->error);
            }
        } else {
            jsonResponse('error', 'Error uploading file.');
        }
    }

    // Close connection
    $conn->close();
}
?>
