<?php
// signup.php

// Include database connection
require_once 'db_connect.php';
session_start(); // Start the session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['new-name'];
    $email = $_POST['new-email'];
    $password = $_POST['new-password'];

    // Validate input
    $username = mysqli_real_escape_string($conn, $username);
    $email = mysqli_real_escape_string($conn, $email);
    $password = mysqli_real_escape_string($conn, $password);

    // Hash password
    $hashed_password = md5($password);

    // SQL query to insert new user
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";

    if (mysqli_query($conn, $sql)) {
        // Store the username in the session
        $_SESSION['username'] = $username;

        // Redirect to home page after successful registration
        header("Location: /website/home.php");
        exit(); // Ensure no further code is executed after the redirect
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>
