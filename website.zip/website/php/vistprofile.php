<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="../Css/profile.css">
    <link rel="stylesheet" href="../Css/product_card.css">
</head>
<body>
    <div class="navbar" id="navbar">
        <div class="logo"><img src="../assets/logo/LOGO2.png" alt="Logo"></div>
        <div class="nav-links"></div>
    </div>
    <div class="container">
        <div class="profile">
            <div class="profile-pic"></div>
            <h1 class="user-name">User Name</h1>
            <p class="product-type">Type of product that you sell / or work</p>
            <div class="about-section">
                <h2>Who am i ?</h2>
                <p>About .......................................................</p>
            </div>
            <div class="buttons">
                <button class="btn" onclick="showContainer(event, 'products')">Products</button>
                <button class="btn" onclick="showContainer(event, 'cours')">Cours</button>
                <button class="btn" onclick="showContainer(event, 'announces')">Announces</button>
                <?php
                    session_start();
                    if(isset($_SESSION['user'])) {
                        // Show add product button only if the user is logged in
                        echo '<button class="btn-add">+</button>';
                    }
                ?>
            </div>
            <?php
                // Display the form for adding a product only if the user is logged in
                if(isset($_SESSION['user'])) {
                    echo '
                    <form action="../php/insert.php" method="post">
                        <label for="name">Product Name:</label>
                        <input type="text" name="name" id="name" required>
                        
                        <label for="price">Price:</label>
                        <input type="number" name="price" id="price" step="0.01" required>
                        
                        <label for="color">Color:</label>
                        <input type="text" name="color" id="color">
                        
                        <label for="description">Description:</label>
                        <textarea name="description" id="description" rows="4"></textarea>
                        
                        <button type="submit">Add Product</button>
                    </form>';
                }
            ?>
            <div id="products" class="content-container">
                <div class="product-container" id="product-card">
                    <!-- Product cards will be dynamically generated here -->
                </div>
            </div>
            <div id="cours" class="content-container" style="display: none;">Cours content...</div>
            <div id="announces" class="content-container" style="display: none;">Announces content...</div>
        </div>
    </div>
    <script src="../js/container.js"></script>
    <script src="../js/add_product.js"></script>
</body>
</html>
