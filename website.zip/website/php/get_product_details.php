<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbs";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate and sanitize input
if (!isset($_GET['id'])) {
    echo json_encode(array('error' => 'Product ID is not specified.'));
    exit;
}

$product_id = intval($_GET['id']); // Convert to integer for security

// Fetch product details from database
$sql = "SELECT * FROM products WHERE id = $product_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Prepare JSON response
    $response = array(
        'image' => 'uploads/' . htmlspecialchars($row["product_image"]),
        'price' => htmlspecialchars($row["product_price"]),
        'name' => htmlspecialchars($row["product_name"]),
        'description' => htmlspecialchars($row["product_description"]),
        'colors' => json_decode($row["product_colors"]), // Assuming product_colors is stored as JSON in the database
        'sizes' => json_decode($row["product_sizes"]) // Assuming product_sizes is stored as JSON in the database
    );

    echo json_encode($response);
} else {
    echo json_encode(array('error' => 'Product not found.'));
}

$conn->close();
?>
