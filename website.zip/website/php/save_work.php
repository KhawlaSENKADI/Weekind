<?php
// Function to return JSON response
function jsonResponse($status, $message) {
    header('Content-Type: application/json');
    echo json_encode(array('status' => $status, 'message' => $message));
    exit;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbs";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        jsonResponse('error', 'Connection failed: ' . $conn->connect_error);
    }

    // Process form data
    $work_title = $_POST['work_title'];
    $work_about = $_POST['work_about'];

    // File upload handling (example: work_image)
    $target_dir = "uploads/"; // Directory where the file will be stored
    $target_file = $target_dir . basename($_FILES["work_image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["work_image"]["tmp_name"]);
    if ($check !== false) {
        // File is an image
        $uploadOk = 1;
    } else {
        // File is not an image
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["work_image"]["size"] > 500000) {
        jsonResponse('error', 'Sorry, your file is too large.');
    }

        // Allow certain file formats
    if (!in_array($imageFileType, array("jpg", "jpeg", "png", "gif"))) {
        jsonResponse('error', 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.');
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        jsonResponse('error', 'Sorry, your file was not uploaded.');
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["work_image"]["tmp_name"], $target_file)) {
            // File uploaded successfully, now insert data into database
            $sql = "INSERT INTO work_gallery (work_title, work_about, work_image)
                    VALUES ('$work_title', '$work_about', '$target_file')";

            if ($conn->query($sql) === TRUE) {
                jsonResponse('success', 'New work added successfully');
            } else {
                jsonResponse('error', 'Error adding work: ' . $conn->error);
            }
        } else {
            jsonResponse('error', 'Sorry, there was an error uploading your file.');
        }
    }

    // Close connection
    $conn->close();
}
?>
