<?php
// Function to return JSON response
function jsonResponse($status, $message) {
    header('Content-Type: application/json');
    echo json_encode(array('status' => $status, 'message' => $message));
    exit;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "dbs";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        jsonResponse('error', 'Connection failed: ' . $conn->connect_error);
    }

    // Process form data
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_quantity = $_POST['product_quantity'];
    $product_size = $_POST['product_size'];
    $product_color = $_POST['product_color'];
    $product_about = $_POST['product_about'];



    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        jsonResponse('error', 'Sorry, your file was not uploaded.');
    } else {
        // if everything is ok, try to upload file
        if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
            // File uploaded successfully, now insert data into database
            $sql = "INSERT INTO products (product_name, product_price, product_quantity, product_size, product_color, product_about, product_image)
                    VALUES ('$product_name', '$product_price', '$product_quantity', '$product_size', '$product_color', '$product_about', '$target_file')";

            if ($conn->query($sql) === TRUE) {
                jsonResponse('success', 'New product added successfully');
            } else {
                jsonResponse('error', 'Error adding product: ' . $conn->error);
            }
        } else {
            jsonResponse('error', 'Sorry, there was an error uploading your file.');
        }
    }

    // Close connection
    $conn->close();
}
?>
