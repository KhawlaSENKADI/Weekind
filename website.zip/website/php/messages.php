<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sender = $_POST['sender'];
    $receiver = $_POST['receiver'];
    $message = $_POST['message'];

    // Check if conversation exists
    $stmt = $conn->prepare("SELECT id FROM conversations WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?)");
    $stmt->bind_param("ssss", $sender, $receiver, $receiver, $sender);
    $stmt->execute();
    $stmt->bind_result($conversation_id);
    $stmt->fetch();
    $stmt->close();

    // If no conversation, create one
    if (!$conversation_id) {
        $stmt = $conn->prepare("INSERT INTO conversations (sender, receiver) VALUES (?, ?)");
        $stmt->bind_param("ss", $sender, $receiver);
        $stmt->execute();
        $conversation_id = $stmt->insert_id;
        $stmt->close();
    }

    // Insert message
    $stmt = $conn->prepare("INSERT INTO messages (conversation_id, sender, receiver, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $conversation_id, $sender, $receiver, $message);
    $stmt->execute();
    $stmt->close();

    echo "Message sent successfully";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $sender = $_GET['sender'];
    $receiver = $_GET['receiver'];

    // Get conversation ID
    $stmt = $conn->prepare("SELECT id FROM conversations WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?)");
    $stmt->bind_param("ssss", $sender, $receiver, $receiver, $sender);
    $stmt->execute();
    $stmt->bind_result($conversation_id);
    $stmt->fetch();
    $stmt->close();

    if ($conversation_id) {
        $stmt = $conn->prepare("SELECT sender, receiver, message, timestamp FROM messages WHERE conversation_id=? ORDER BY timestamp ASC");
        $stmt->bind_param("i", $conversation_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $messages = array();
        while ($row = $result->fetch_assoc()) {
            $messages[] = $row;
        }
        echo json_encode($messages);
    } else {
        echo json_encode([]);
    }
    exit();
}

$conn->close();
?>
