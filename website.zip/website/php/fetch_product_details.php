<?php
// Include database connection
include_once 'db_connection.php';

// Get product ID from GET parameters
$productId = $_GET['productId'];

// Fetch product details from database
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$productId]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

// Return product details as JSON
echo json_encode($product);
?>
