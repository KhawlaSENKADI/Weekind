
document.addEventListener("DOMContentLoaded", function() {
    const productContainer = document.querySelector('.product');
    const productCards = Array.from(productContainer.children);
    const showMoreBtn = document.createElement('button');
    showMoreBtn.classList.add('show-more-btn');
    showMoreBtn.textContent = 'Show More';
    document.body.appendChild(showMoreBtn);

    let productsPerPage = 30; // 6 cards per row * 5 rows
    let currentPage = 1;

    function displayProducts() {
        const totalProducts = currentPage * productsPerPage;
        productCards.forEach((card, index) => {
            if (index < totalProducts) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });

        if (totalProducts >= productCards.length) {
            showMoreBtn.style.display = 'none';
        } else {
            showMoreBtn.style.display = 'block';
        }
    }

    showMoreBtn.addEventListener('click', function() {
        currentPage++;
        displayProducts();
    });

    // Initial display
    displayProducts();
});

function openSection(event, sectionName) {
    var i, tabcontent, tablinks;
    
    // Hide all tab contents
    tabcontent = document.getElementsByClassName("profile__section__tab__tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    
    // Deactivate all tab buttons
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
    }
    
    // Show the clicked tab content and activate the clicked button
    document.getElementById(sectionName).style.display = "block";
    event.currentTarget.classList.add("active");
}

// Initially show the default tab (work gallery)
document.getElementById("defaultOpen").click();

