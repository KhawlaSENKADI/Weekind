function addColorInput(containerId) {
  const colorContainer = document.getElementById(containerId);
  const newColorInput = document.createElement('input');
  newColorInput.type = 'color';
  newColorInput.name = 'product_colors[]';
  colorContainer.appendChild(newColorInput);
}

function submitForm(formId, popupId) {
  var form = document.getElementById(formId);
  var formData = new FormData(form);

  fetch('php/save_product.php', {
          method: 'POST',
          body: formData
      })
      .then(response => response.json())
      .then(data => {
          if (data.status === 'success') {
              alert(data.message);
              togglePopup(popupId); // Close the popup
          } else {
              alert('Error: ' + data.message);
          }
      })
      .catch(error => {
          console.error('Error:', error);
      });
}
