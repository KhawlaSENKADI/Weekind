const translations = {
    en: {
        welcome: "Welcome to",
        productName: "Weekind",
        getStarted: "Get started",
        aboutUs: "About Us",
        aboutDesc1: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        aboutDesc2: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        features: "Features",
        feature1Title: "Feature 1",
        feature1Desc: "Description of the feature and its benefits.",
        feature2Title: "Feature 2",
        feature2Desc: "Description of the feature and its benefits.",
        feature3Title: "Feature 3",
        feature3Desc: "Description of the feature and its benefits.",
        signupFormTitle: "Sign-up Form",
        loginFormTitle: "Login Form",
        cancel: "Cancel",
        haveAccount: "Already have an account?",
        login: "Log In",
        noAccount: "Don't have an account yet?",
        signup: "Sign Up"
    },
    fr: {
        welcome: "Bienvenue chez",
        productName: "Weekind",
        getStarted: "Commencer",
        aboutUs: "À propos de nous",
        aboutDesc1: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
        aboutDesc2: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
        features: "Caractéristiques",
        feature1Title: "Caractéristique 1",
        feature1Desc: "Description de la caractéristique et de ses avantages.",
        feature2Title: "Caractéristique 2",
        feature2Desc: "Description de la caractéristique et de ses avantages.",
        feature3Title: "Caractéristique 3",
        feature3Desc: "Description de la caractéristique et de ses avantages.",
        signupFormTitle: "Formulaire d'inscription",
        loginFormTitle: "Formulaire de connexion",
        cancel: "Annuler",
        haveAccount: "Vous avez déjà un compte?",
        login: "Se connecter",
        noAccount: "Vous n'avez pas encore de compte?",
        signup: "S'inscrire"
    },
    ar: {
        welcome: "مرحبًا بك في",
        productName: "Weekind",
        getStarted: "ابدأ",
        aboutUs: "معلومات عنا",
        aboutDesc1: "لوريم إيبسوم هو نص شكلي (بمعنى أن الغاية هي الشكل وليس المحتوى) ويُستخدم في صناعات المطابع ودور النشر.",
        aboutDesc2: "كان لوريم إيبسوم ولايزال المعيار للنص الشكلي منذ القرن الخامس عشر عندما قامت مطبعة مجهولة برص مجموعة من الأحرف بشكل عشوائي.",
        features: "الميزات",
        feature1Title: "الميزة 1",
        feature1Desc: "وصف الميزة وفوائدها.",
        feature2Title: "الميزة 2",
        feature2Desc: "وصف الميزة وفوائدها.",
        feature3Title: "الميزة 3",
        feature3Desc: "وصف الميزة وفوائدها.",
        signupFormTitle: "نموذج التسجيل",
        loginFormTitle: "نموذج الدخول",
        cancel: "إلغاء",
        haveAccount: "هل لديك حساب بالفعل؟",
        login: "تسجيل الدخول",
        noAccount: "ليس لديك حساب بعد؟",
        signup: "اشتراك"
    }
};

function changeLanguage() {
    const language = document.getElementById('languageSwitcher').value;
    const elements = document.querySelectorAll('[data-key]');

    elements.forEach(element => {
        const key = element.getAttribute('data-key');
        element.textContent = translations[language][key];
    });

    // Update direction for Arabic
    if (language === 'ar') {
        document.body.style.direction = 'rtl';
    } else {
        document.body.style.direction = 'ltr';
    }
}
