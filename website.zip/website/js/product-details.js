// public/product-details.js
document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/product')
        .then(response => response.json())
        .then(product => {
            document.getElementById('product-title').innerText = product.title;
            document.getElementById('product-description').innerText = product.description;
            document.getElementById('product-price').innerText = `$ ${product.price.toFixed(2)}`;
            document.getElementById('product-image').src = product.imageUrl;

            const colorsWrap = document.getElementById('colors');
            product.colors.forEach((color, index) => {
                const colorElement = document.createElement('span');
                colorElement.className = 'colors';
                if (index === 0) colorElement.classList.add('selected');
                colorElement.style.backgroundColor = color;
                colorElement.onclick = () => selectColor(colorElement);
                colorsWrap.appendChild(colorElement);
            });

            const sizesWrap = document.getElementById('sizes');
            product.sizes.forEach((size, index) => {
                const sizeElement = document.createElement('span');
                sizeElement.className = 'size';
                if (index === 2) sizeElement.classList.add('selected');
                sizeElement.innerText = size;
                sizeElement.onclick = () => selectSize(sizeElement);
                sizesWrap.appendChild(sizeElement);
            });
        });
});

function selectColor(element) {
    document.querySelectorAll('.colors').forEach(color => color.classList.remove('selected'));
    element.classList.add('selected');
}

function selectSize(element) {
    document.querySelectorAll('.size').forEach(size => size.classList.remove('selected'));
    element.classList.add('selected');
}

function addToCart() {
    alert('Added to cart!');
}

function addToWishlist() {
    alert('Added to wishlist!');
}
