function createLoginForm() {
    var form = document.getElementById("loginForm");
    form.innerHTML = `
        <label class="form-label" for="name">Username:</label>
        <input class="form-input" type="text" placeholder="Enter Your Username" id="name" name="name" required>
        <label class="form-label" for="email">Email:</label>
        <input class="form-input" type="email" placeholder="Enter Your Email" id="email" name="email" required>
        <label class="form-label" for="password">Password:</label>
        <input class="form-input" type="password" placeholder="Enter Your Password" id="password" name="password" required>
        <button class="btn-submit" type="submit">Submit</button>
    `;
}

function createSignupForm() {
    var form = document.getElementById("signupForm");
    form.innerHTML = `
        <label class="form-label" for="new-name">Username:</label>
        <input class="form-input" type="text" placeholder="Enter Your Username" id="new-name" name="new-name" required>
        <label class="form-label" for="new-email">Email:</label>
        <input class="form-input" type="email" placeholder="Enter Your Email" id="new-email" name="new-email" required>
        <label class="form-label" for="new-password">Password:</label>
        <input class="form-input" type="password" placeholder="Enter Your Password" id="new-password" name="new-password" required>
        <button class="btn-submit" type="submit">Submit</button>
    `;
}

// Call the functions to create the forms initially
createLoginForm();
createSignupForm();


function togglePopup(popupId) {
    var popup = document.getElementById(popupId);
    popup.classList.toggle("show");
}



